package com.edstem.interview.edstem.dto;

import java.util.List;

public class AuthorsDTO {
	
	private List<AuthorDTO> authors;

	public List<AuthorDTO> getAuthors() {
		return authors;
	}

	public void setAuthors(List<AuthorDTO> authors) {
		this.authors = authors;
	}
	
	

}
