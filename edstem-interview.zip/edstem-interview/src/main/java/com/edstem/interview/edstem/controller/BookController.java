package com.edstem.interview.edstem.controller;

import java.util.Objects;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.edstem.interview.edstem.domain.Author;
import com.edstem.interview.edstem.domain.Book;
import com.edstem.interview.edstem.dto.AuthorDTO;
import com.edstem.interview.edstem.dto.BookDTO;
import com.edstem.interview.edstem.repository.AuthorRepository;
import com.edstem.interview.edstem.repository.BookRepository;

@RestController
@RequestMapping("/book")
public class BookController {
	
	private BookRepository bookRepository;
	
	private AuthorRepository authorRepository;
	
	
	public BookController(BookRepository bookRepository,AuthorRepository authorRepository) {
		super();
		this.bookRepository = bookRepository;
		this.authorRepository  = authorRepository;
	}
	@PostMapping
	public BookDTO saveBook(@RequestBody BookDTO bookDTO) {
		Book book = new Book();
		book.setName(bookDTO.getBookName());
		book.setYear(bookDTO.getPublishedYear());
		Optional<Author> author = authorRepository.findById(bookDTO.getAuthor().getId());
		author.filter(Objects::nonNull).ifPresentOrElse(book::setAuthor, () -> {
			Author au = new Author();
			au.setName(bookDTO.getAuthor().getName());
			book.setAuthor(authorRepository.save(au));
		});
		Book save = bookRepository.save(book);
		bookDTO.setId(save.getId());
		return bookDTO;
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<BookDTO> findById(@PathVariable(value = "id") Integer id) {
		Optional<Book> book = bookRepository.findById(id);
		BookDTO bookDTO = new BookDTO();
		book.filter(Objects::nonNull).ifPresent(i -> {
			bookDTO.setBookName(i.getName());
			bookDTO.setPublishedYear(i.getYear());
			Author author = i.getAuthor();
			AuthorDTO authorDTO = new AuthorDTO();
			authorDTO.setName(author.getName());
			authorDTO.setId(author.getId());
			bookDTO.setAuthor(authorDTO);
		});
		HttpStatus status = bookDTO == null ? HttpStatus.NOT_FOUND : HttpStatus.OK;
		return new ResponseEntity<BookDTO>(bookDTO, status);
	}
	
}
