package com.edstem.interview.edstem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdstemInterviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdstemInterviewApplication.class, args);
	}

}
