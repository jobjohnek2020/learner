package com.edstem.interview.edstem.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edstem.interview.edstem.domain.Author;
import com.edstem.interview.edstem.dto.AuthorDTO;
import com.edstem.interview.edstem.dto.AuthorsDTO;
import com.edstem.interview.edstem.dto.BookDTO;
import com.edstem.interview.edstem.repository.AuthorRepository;

@RestController
@RequestMapping("/author")
public class AuthorController {
	
	private AuthorRepository authorRepository;
	
	
	public AuthorController(AuthorRepository authorRepository) {
		super();
		this.authorRepository = authorRepository;
	}
	
	@PostMapping
	public AuthorDTO saveAuthor(@RequestBody AuthorDTO authorDTO) {
		Author author = new Author();
		author.setName(authorDTO.getName());
		Author save = authorRepository.save(author);
		AuthorDTO saved = new AuthorDTO();
		BeanUtils.copyProperties(save, saved);
		return saved;
	}
	@GetMapping
	public AuthorsDTO findAll() {
		List<Author> authors = authorRepository.findAll();
		List<AuthorDTO> authorDTOs = new ArrayList<>();
		authors.forEach(author -> {
			AuthorDTO authorDTO = new AuthorDTO();
			authorDTO.setId(author.getId());
			authorDTO.setName(author.getName());
			List<BookDTO> books = new ArrayList<>();
			if(!CollectionUtils.isEmpty(author.getBooks())) {
				author.getBooks().forEach(book -> {
					BookDTO bookDTO = new BookDTO();
					bookDTO.setBookName(book.getName());
					bookDTO.setPublishedYear(book.getYear());
					bookDTO.setId(book.getId());
					books.add(bookDTO);
				});
				authorDTO.setBooks(books);
			}
			authorDTOs.add(authorDTO);
		});
		AuthorsDTO authorsDTO = new AuthorsDTO();
		authorsDTO.setAuthors(authorDTOs);
		return authorsDTO;
	}
}
